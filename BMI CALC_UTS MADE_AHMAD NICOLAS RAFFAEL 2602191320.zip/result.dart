import 'package:flutter/material.dart';

class BMI extends StatelessWidget {
  final double bmi;
  final int gender;

  const BMI({required this.bmi, required this.gender, super.key});

  @override
  Widget build(BuildContext context) {
    String weightClass = "";
    if (gender == 0) {
      if (bmi < 18) {
        weightClass =
            "Underweight \n \n You should eat some more, but make sure not to overeat.";
      } else if (bmi >= 18 && bmi <= 25) {
        weightClass =
            "Normal \n \n You should maintain your diet and keep doing exercise.";
      } else if (bmi > 25 && bmi <= 27) {
        weightClass =
            "Overweight \n \n You should reduce consumption of sugars and fats. You should also start exercising";
      } else {
        weightClass =
            "Obese \n \n You should progressively reduce your intake of calories while also increasing your frequecy of exercise";
      }
    } else {
      if (bmi < 17) {
        weightClass =
            "Underweight \n \n You should eat some more, but make sure not to overeat.";
      } else if (bmi >= 17 && bmi <= 23) {
        weightClass =
            "Normal \n \n You should maintain your diet and keep doing exercise.";
      } else if (bmi > 23 && bmi <= 27) {
        weightClass =
            "Overweight \n \n You should reduce consumption of sugars and fats. You should also start exercising";
      } else {
        weightClass =
            "Obese \n \n You should progressively reduce your intake of calories while also increasing your frequecy of exercise";
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: const Center(
          child: Text('BMI Calculator',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24.0)),
        ),
      ),
      body: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                children: <Widget>[
                  const Text(
                    'Your BMI is: \n ',
                    //${bmi.toStringAsFixed(2)} kg/m^2 \n \nYour body type is $weightClass',
                    style: TextStyle(
                      fontSize: 30.0,
                      color: Colors.black,
                    ),
                  ),
                  Text(
                    '${bmi.toStringAsFixed(2)} kg/m^2 \n \n',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 36.0,
                      color: Colors.black,
                    ),
                  ),
                  Text(
                    'Your body type is $weightClass',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 36.0,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 0),
            Container(
              padding: const EdgeInsets.all(10.0),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text(
                  'RE-CALCULATE BMI',
                  style: TextStyle(fontSize: 36.0),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
