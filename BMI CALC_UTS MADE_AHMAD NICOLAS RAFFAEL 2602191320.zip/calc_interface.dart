import 'package:flutter/material.dart';
import 'package:bmi_utss/result.dart';

class Bmicalc extends StatefulWidget {
  const Bmicalc({super.key}); //not mandatory
  @override
  UserData createState() => UserData();
}

class UserData extends State<Bmicalc> {
  int gender = 0;
  int height = 150;
  int weight = 50;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(
          child: Text('BMI Calculator',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30.0)),
        ),
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(20.0), //common flutter padding
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  const Text(
                    'Gender',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 30.0,
                      color: Colors.blue,
                    ),
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      GestureDetector(
                        //onPressed:
                        onTap: () {
                          setState(() {
                            gender = 0;
                          });
                        },
                        child: Container(
                          height: 100.0,
                          width: 100.0,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: gender == 0 ? Colors.blue : Colors.black,
                          ),
                          child: const Icon(
                            Icons.male,
                            size: 70.0,
                            color: Colors.orange,
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 150.0,
                        height: 120,
                      ),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            gender = 1;
                          });
                        },
                        child: Container(
                          height: 100.0,
                          width: 100.0,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: gender == 1 ? Colors.pink : Colors.black,
                          ),
                          child: const Icon(
                            Icons.female,
                            size: 70.0,
                            color: Colors.orange,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 0),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    'Height (cm): $height ',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 30.0,
                        color: Colors.blue),
                  ),
                  Slider(
                    thumbColor: Colors.blueAccent,
                    value: height
                        .toDouble(), //value requires double, int not possible
                    min: 110.0,
                    max: 230.0,
                    onChanged: (double inputHeight) {
                      setState(() {
                        height = inputHeight.toInt();
                      });
                    },
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20.0),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text(
                    'Weight (kg): $weight',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 30.0,
                        color: Colors.blue),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      FloatingActionButton(
                        backgroundColor: Colors.blue,
                        onPressed: () {
                          setState(() {
                            weight--;
                          });
                        },
                        child: const Text(
                          '-',
                          style: TextStyle(fontSize: 36.0),
                        ),
                      ),
                      const SizedBox(width: 150.0),
                      FloatingActionButton(
                        backgroundColor: Colors.blue,
                        onPressed: () {
                          setState(() {
                            weight++;
                          });
                        },
                        child: const Text(
                          '+',
                          style: TextStyle(fontSize: 36.0),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 0),
          Container(
            padding: const EdgeInsets.all(15),
            child: ElevatedButton(
              onPressed: () {
                double bmiHeight = height / 100;
                double bmi = weight / (bmiHeight * bmiHeight);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => BMI(bmi: bmi, gender: gender),
                  ),
                );
                //Navigator.pushNamed(context, '/BMI');
              },
              child: const Text(
                'Calculate BMI',
                style: TextStyle(fontSize: 36.0),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
